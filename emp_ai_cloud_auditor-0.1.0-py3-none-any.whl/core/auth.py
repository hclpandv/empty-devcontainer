from azure.identity import DefaultAzureCredential
from core.config import get_settings


class AzureAuth:
    def __init__(self):
        settings = get_settings()

        self.credential = DefaultAzureCredential()
        self.subscription_id = settings.azure_subscription_id
