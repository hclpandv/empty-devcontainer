import typer
from rich import print
from rich.table import Table

from importlib import resources
from pathlib import Path
import shutil

from core.auth import AzureAuth
from core.clients.arg_client import ResourceGraphCollector
from core.execution.arg_runner import ARGExecutor
from core.execution.orchestrator import Orchestrator
from core.rules.registry import RuleRegistry

app = typer.Typer()

# =========================
# AUDIT COMMAND
# =========================
@app.command()
def audit():
    emp_dir = Path.cwd() / ".emp"

    if not emp_dir.exists():
        print("[red]❌ No .emp workspace found in this directory[/red]")
        print("[yellow]👉 Run: emp-ai-cloud-auditor init[/yellow]")
        raise typer.Exit(1)

    print("[bold blue]Starting CSPM Audit...[/bold blue]")

    auth = AzureAuth()
    collector = ResourceGraphCollector(auth)
    registry = RuleRegistry(emp_dir / "rules")
    executor = ARGExecutor(collector)
    orchestrator = Orchestrator(registry=registry, executor=executor)

    findings = orchestrator.run()

    table = Table(title="Security Findings")

    table.add_column("Severity", style="red")
    table.add_column("Title", style="bold")
    table.add_column("Category")
    table.add_column("Resource", overflow="fold")

    for f in findings:
        table.add_row(
            f.severity,
            f.title,
            f.category,
            f.resource_id,
        )

    print(table)


# =========================
# INIT COMMAND
# =========================
@app.command()
def init():
    """
    Initialize local EMP workspace (.emp)
    and copy default CSPM rules.
    """

    emp_home = Path.cwd() / ".emp"
    rules_dir = emp_home / "rules"

    if emp_home.exists():
        print("[yellow]Project already initialized (.emp exists)[/yellow]")
        return

    print("[bold blue]Initializing EMP CSPM workspace...[/bold blue]")

    rules_dir.mkdir(parents=True, exist_ok=True)

    package_rules = resources.files("core.rules.embedded")

    if not package_rules.exists():
        print("[red]No built-in rules found in package[/red]")
        raise typer.Exit(1)

    for item in package_rules.rglob("*.yaml"):
        if item.is_file():
            relative_path = item.relative_to(package_rules)
            target = rules_dir / relative_path
            target.parent.mkdir(parents=True, exist_ok=True)

            shutil.copy2(item, target)

    print(f"[green]EMP initialized successfully at {emp_home}[/green]")
    print("[dim]You can now edit rules in ./.emp/rules[/dim]")


# =========================
# REGISTRATION
# =========================
app.command()(audit)
app.command()(init)


def main():
    app()