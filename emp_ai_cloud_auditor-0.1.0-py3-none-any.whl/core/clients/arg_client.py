from azure.mgmt.resourcegraph import ResourceGraphClient
from azure.mgmt.resourcegraph.models import QueryRequest

from core.auth import AzureAuth


class ResourceGraphCollector:
    def __init__(self, auth: AzureAuth):
        self.auth = auth
        self.client = ResourceGraphClient(auth.credential)

    # -------------------------
    # Generic query runner
    # -------------------------
    def _run_query(self, query: str):
        request = QueryRequest(
            subscriptions=[self.auth.subscription_id],
            query=query,
        )
        response = self.client.resources(request)
        return response.data

    # -------------------------
    # Security-relevant queries
    # -------------------------
    def get_public_ips(self):
        query = """
        Resources
        | where type =~ 'microsoft.network/publicipaddresses'
        | project id, name, location, properties.ipAddress
        """
        return self._run_query(query)

    def get_virtual_machines(self):
        query = """
        Resources
        | where type =~ 'microsoft.compute/virtualmachines'
        | project id, name, location, resourceGroup
        """
        return self._run_query(query)

    def get_nsgs(self):
        query = """
        Resources
        | where type =~ 'microsoft.network/networksecuritygroups'
        | project id, name, location
        """
        return self._run_query(query)

    def get_storage_accounts(self):
        query = """
        Resources
        | where type =~ 'microsoft.storage/storageaccounts'
        | project id, name, location
        """
        return self._run_query(query)

    # -------------------------
    # Aggregated inventory
    # -------------------------
    def collect_all(self):
        return {
            "public_ips": self.get_public_ips(),
            "virtual_machines": self.get_virtual_machines(),
            "nsgs": self.get_nsgs(),
            "storage_accounts": self.get_storage_accounts(),
        }

    def collect_query(self, query: str):
        """
        Generic ARG query interface used by CSPM engine.
        This is what orchestrator/engine expects.
        """

        request = QueryRequest(
            subscriptions=[self.auth.subscription_id],
            query=query,
        )

        response = self.client.resources(request)
        return response.data
