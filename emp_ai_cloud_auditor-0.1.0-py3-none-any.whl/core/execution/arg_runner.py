class ARGExecutor:
    def __init__(self, collector):
        self.collector = collector

    def run(self, query: str):
        return self.collector.collect_query(query)
