from collections import defaultdict
from core.models.finding import Finding


class Normalizer:
    """
    Converts raw ARG rows → CSPM-grade Findings
    Handles:
    - dedup (resource-level)
    - grouping
    - evidence structuring
    - risk scoring
    """

    def normalize(self, rule, rows):
        # -------------------------
        # 1. Group by RESOURCE ID
        # -------------------------
        grouped = defaultdict(list)

        for row in rows:
            resource_id = row.get("id")
            grouped[resource_id].append(row)

        findings = []

        # -------------------------
        # 2. Convert to Finding
        # -------------------------
        for resource_id, items in grouped.items():
            primary = items[0]

            findings.append(
                Finding(
                    rule_id=rule.id,
                    category=rule.category,
                    title=rule.title,
                    severity=rule.severity,
                    resource_id=resource_id,
                    resource_type=rule.resource_type,
                    subscription_id=primary.get("subscriptionId"),
                    region=primary.get("location"),
                    evidence={
                        "rows": items,
                        "query": rule.query,
                        "tags": rule.tags,
                    },
                    occurrences=len(items),
                    risk_score=self._score(rule.severity, len(items)),
                )
            )

        return findings

    # -------------------------
    # 3. CSPM risk scoring model
    # -------------------------
    def _score(self, severity: str, occurrences: int) -> float:
        base = {
            "CRITICAL": 10,
            "HIGH": 7,
            "MEDIUM": 5,
            "LOW": 2,
        }.get(severity.upper(), 1)

        return base * (1 + min(occurrences - 1, 2) * 0.2)
