from core.models.finding import Finding
from core.execution.normalizer import Normalizer
from rich.progress import Progress


class Orchestrator:
    def __init__(self, registry, executor):
        self.registry = registry
        self.executor = executor
        self.normalizer = Normalizer()

    def run(self):
        all_findings = []
        rules = self.registry.get_rules()

        with Progress() as progress:
            task = progress.add_task(
                "Evaluating CSPM rules...",
                total=len(rules)
            )

            for rule in rules:
                progress.update(task, description=f"Running {rule.id}")
                rows = self.executor.run(rule.query)
                findings = self.normalizer.normalize(rule, rows)
                all_findings.extend(findings)
                progress.advance(task)

        return all_findings