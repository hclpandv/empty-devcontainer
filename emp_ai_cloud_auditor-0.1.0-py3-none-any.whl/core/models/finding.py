from dataclasses import dataclass, field
from typing import Any, Dict

@dataclass
class Finding:
    # rule metadata
    rule_id: str
    title: str
    severity: str
    category: str 

    # resource metadata
    resource_id: str
    resource_type: str

    subscription_id: str | None = None
    region: str | None = None

    # CSPM enrichment
    occurrences: int = 1
    risk_score: float = 0.0

    # evidence payload
    evidence: Dict[str, Any] = field(default_factory=dict)