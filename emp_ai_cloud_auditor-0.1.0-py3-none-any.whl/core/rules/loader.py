import yaml
from pathlib import Path
from core.rules.schema import Rule


class RuleLoader:
    def __init__(self, rules_path: Path):
        self.rules_path = Path(rules_path)

    def load_rules(self) -> list[Rule]:
        rules = []

        for file in self.rules_path.rglob("*.yaml"):
            with open(file, "r") as f:
                data = yaml.safe_load(f)

            rule = Rule(**data)

            if rule.enabled:
                rules.append(rule)

        return rules