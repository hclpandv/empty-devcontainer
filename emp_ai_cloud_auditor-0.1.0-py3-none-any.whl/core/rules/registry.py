import time
from core.rules.loader import RuleLoader
from pathlib import Path


class RuleRegistry:
    def __init__(self, rules_path: Path, refresh_interval=60):
        self.loader = RuleLoader(Path(rules_path))
        self.refresh_interval = refresh_interval

        self._rules = []
        self._last_loaded = 0

    def get_rules(self):
        now = time.time()

        if now - self._last_loaded > self.refresh_interval:
            self._reload()

        return self._rules

    def _reload(self):
        print("[Registry] Loading rules...")
        self._rules = self.loader.load_rules()
        self._last_loaded = time.time()