from pydantic import BaseModel
from typing import List, Optional


class Rule(BaseModel):
    id: str
    title: str
    description: str
    severity: str
    category: str

    query: str
    resource_type: str

    tags: List[str] = []
    enabled: bool = True

    remediation: Optional[str] = None
