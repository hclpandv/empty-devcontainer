from pydantic import BaseModel
from typing import Optional


class AzureResource(BaseModel):
    id: str
    name: str
    type: str
    location: Optional[str] = None
    resource_group: Optional[str] = None
